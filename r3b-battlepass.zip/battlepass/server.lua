-- ============================================================
--  R3B TACTICS | Battle Pass (SERVER)
--  Rewards, XP and claims are server-authoritative.
--  The client only sends an action name plus a session token.
--
--  Database
--  --------
--  Opens the legacy file battlepass.db (server working directory)
--  first, so existing players are kept, then falls back to the
--  resource folder. Missing columns are added in place. Writes are
--  synchronous, so a restart cannot drop a claim that was just granted.
-- ============================================================

if type(BP) ~= "table" or not BP.Rewards or not BP.Days then
    outputDebugString("[BattlePass] shared.lua did not load. Check meta.xml script order.", 1)
    return
end

local db
local Data, Tokens, Strikes, LastReq, PrevSkin, LastVeh = {}, {}, {}, {}, {}, {}

local COLUMNS = {
    { "name",         "TEXT",    "''" },
    { "xp",           "INTEGER", "0" },
    { "claimed",      "INTEGER", "0" },
    { "last_claim",   "TEXT",    "''" },
    { "mission_date", "TEXT",    "''" },
    { "missions",     "TEXT",    "'[]'" },
    { "coins",        "INTEGER", "0" },
    { "emeralds",     "INTEGER", "0" },
    { "rp",           "INTEGER", "0" },
    { "skin_owned",   "INTEGER", "0" },
    { "equipped",     "INTEGER", "0" },
}

local SCHEMA = [[CREATE TABLE IF NOT EXISTS bp_players (
    account      TEXT PRIMARY KEY,
    name         TEXT DEFAULT '',
    xp           INTEGER DEFAULT 0,
    claimed      INTEGER DEFAULT 0,
    last_claim   TEXT DEFAULT '',
    mission_date TEXT DEFAULT '',
    missions     TEXT DEFAULT '[]',
    coins        INTEGER DEFAULT 0,
    emeralds     INTEGER DEFAULT 0,
    rp           INTEGER DEFAULT 0,
    skin_owned   INTEGER DEFAULT 0,
    equipped     INTEGER DEFAULT 0
)]]

-- ---------------------------------------------------------------- db
local function dbCall(conn, sql, ...)
    if not conn then return nil, "no connection" end
    local handle = dbQuery(conn, sql, ...)
    if not handle then
        outputDebugString("[BattlePass] dbQuery rejected: " .. tostring(sql), 1)
        return nil, "rejected"
    end
    local rows, errCode, errMsg = dbPoll(handle, 10000)
    if rows == nil then
        dbFree(handle)
        outputDebugString("[BattlePass] dbPoll timeout: " .. tostring(sql), 1)
        return nil, "timeout"
    end
    if rows == false then
        outputDebugString("[BattlePass] SQL (" .. tostring(errCode) .. ") " .. tostring(errMsg) .. " | " .. tostring(sql), 1)
        return nil, tostring(errMsg or "error")
    end
    return rows, nil
end

local function columnSet(conn)
    local rows = dbCall(conn, "PRAGMA table_info(bp_players)")
    local have = {}
    if rows then
        for _, row in ipairs(rows) do
            if row.name then have[tostring(row.name)] = true end
        end
    end
    return have, rows ~= nil
end

local function ensureSchema(conn)
    if not dbCall(conn, SCHEMA) then return false end
    local have, ok = columnSet(conn)
    if not ok then return false end
    if not have.account then
        outputDebugString("[BattlePass] bp_players has no account column, archiving it and recreating", 1)
        dbCall(conn, "ALTER TABLE bp_players RENAME TO bp_players_backup")
        if not dbCall(conn, SCHEMA) then return false end
        have = columnSet(conn)
    end
    for _, col in ipairs(COLUMNS) do
        if not have[col[1]] then
            local sql = ("ALTER TABLE bp_players ADD COLUMN %s %s DEFAULT %s"):format(col[1], col[2], col[3])
            if not dbCall(conn, sql) then
                outputDebugString("[BattlePass] could not add column " .. col[1], 1)
                return false
            end
            outputDebugString("[BattlePass] migrated missing column: " .. col[1], 3)
            have[col[1]] = true
        end
    end
    dbCall(conn, "CREATE INDEX IF NOT EXISTS idx_bp_xp ON bp_players (xp)")
    return true
end

local function openDB()
    local res = getResourceName(getThisResource())
    local paths = {
        "battlepass.db",
        ":" .. res .. "/battlepass.db",
    }
    for _, path in ipairs(paths) do
        local conn = dbConnect("sqlite", path)
        if conn then
            dbCall(conn, "PRAGMA busy_timeout=5000")
            dbCall(conn, "PRAGMA journal_mode=WAL")
            dbCall(conn, "PRAGMA synchronous=NORMAL")
            if ensureSchema(conn) then
                db = conn
                local count = dbCall(conn, "SELECT COUNT(*) AS n FROM bp_players")
                local n = (count and count[1] and tonumber(count[1].n)) or 0
                outputDebugString(("[BattlePass] database ready (%s) players=%d"):format(path, n), 3)
                return true
            end
            destroyElement(conn)
            outputDebugString("[BattlePass] schema failed, trying next path: " .. path, 2)
        else
            outputDebugString("[BattlePass] dbConnect failed: " .. path, 2)
        end
    end
    outputDebugString("[BattlePass] database unavailable. UI still opens, but progress will not be saved. Make the resource folder writable and restart.", 1)
    return false
end

-- ---------------------------------------------------------------- helpers
local function asInt(v)
    return math.floor(tonumber(v) or 0)
end

local function asStr(v)
    if v == nil or v == false then return "" end
    return tostring(v)
end

local function today()
    local t = getRealTime()
    return ("%04d-%02d-%02d"):format(t.year + 1900, t.month + 1, t.monthday)
end

local function cleanName(p)
    local name = "player"
    if isElement(p) then name = getPlayerName(p) or name end
    name = name:gsub("#%x%x%x%x%x%x", "")
    if #name > 32 then name = name:sub(1, 32) end
    if name == "" then name = "player" end
    return name
end

local function notify(p, msg, kind)
    if isElement(p) then triggerClientEvent(p, "bp:notify", p, msg, kind or "info") end
end

local function strike(p, why)
    if not isElement(p) then return end
    Strikes[p] = (Strikes[p] or 0) + 1
    outputServerLog(("[BattlePass] %s -> %s (%d/%d)"):format(cleanName(p), why, Strikes[p], BP.MaxStrikes))
    if Strikes[p] >= BP.MaxStrikes then
        kickPlayer(p, "Battle Pass: suspicious activity")
    end
end

local ALLOWED = { kills = true, headshots = true, playtime = true, vehicle = true, roundwin = true }
local DIFFS = { easy = true, medium = true, hard = true }

local function normalizeMissions(raw)
    local packed, maxI = {}, 0
    if type(raw) ~= "table" then return {} end
    for key, value in pairs(raw) do
        local index = tonumber(key)
        if index and type(value) == "table" then
            local diff = DIFFS[value.diff] and value.diff or "easy"
            local mtype = ALLOWED[value.type] and value.type or nil
            if mtype then
                local need = math.max(1, asInt(value.need))
                local prog = math.max(0, asInt(value.prog))
                if prog > need then prog = need end
                packed[index] = {
                    type = mtype,
                    diff = diff,
                    need = need,
                    prog = prog,
                    xp = math.max(0, asInt(value.xp ~= nil and value.xp or BP.DiffXP[diff] or 0)),
                    text = asStr(value.text ~= "" and value.text or "Mission"),
                }
                if index > maxI then maxI = index end
            end
        end
    end
    local list = {}
    for i = 1, maxI do
        if packed[i] then list[#list + 1] = packed[i] end
    end
    return list
end

local function decodeMissions(raw)
    if type(raw) == "table" then return normalizeMissions(raw) end
    if type(raw) ~= "string" or raw == "" or raw == "[]" or raw == "{}" or raw == "null" then
        return {}
    end
    local parsed = fromJSON(raw)
    if type(parsed) == "string" then parsed = fromJSON(parsed) end
    if type(parsed) ~= "table" then
        outputDebugString("[BattlePass] unreadable missions JSON, rolling fresh missions", 2)
        return {}
    end
    return normalizeMissions(parsed)
end

local function fresh(key)
    return {
        account = key,
        xp = 0, claimed = 0, last_claim = "", mission_date = "",
        missions = {}, coins = 0, emeralds = 0, rp = 0,
        skin_owned = 0, equipped = 0,
    }
end

local function save(p)
    local d = Data[p]
    if not d or not db or not d.account then return false end
    local name = isElement(p) and cleanName(p) or "player"
    local missions = toJSON(d.missions or {}, true) or "[]"
    local exists, err = dbCall(db, "SELECT account FROM bp_players WHERE account=? LIMIT 1", d.account)
    if not exists then
        outputDebugString("[BattlePass] save lookup failed for " .. d.account .. ": " .. tostring(err), 1)
        return false
    end
    local args = {
        name, d.xp, d.claimed, d.last_claim, d.mission_date, missions,
        d.coins, d.emeralds, d.rp, d.skin_owned, d.equipped, d.account,
    }
    if exists[1] then
        return dbCall(db, [[UPDATE bp_players SET name=?,xp=?,claimed=?,last_claim=?,mission_date=?,missions=?,coins=?,emeralds=?,rp=?,skin_owned=?,equipped=? WHERE account=?]], unpack(args)) ~= nil
    end
    return dbCall(db, [[INSERT INTO bp_players (name,xp,claimed,last_claim,mission_date,missions,coins,emeralds,rp,skin_owned,equipped,account) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)]], unpack(args)) ~= nil
end

local function payload(p)
    local d = Data[p]
    local missions, done = {}, 0
    for i, mission in ipairs(d.missions or {}) do
        missions[i] = {
            text = mission.text, diff = mission.diff,
            need = mission.need, prog = mission.prog, xp = mission.xp,
        }
        if mission.prog >= mission.need then done = done + 1 end
    end
    return {
        xp = d.xp, claimed = d.claimed,
        claimedToday = (d.last_claim == today()),
        allDone = (#missions > 0 and done == #missions),
        missions = missions,
        coins = d.coins, emeralds = d.emeralds, rp = d.rp,
        skin = (d.skin_owned == 1), equipped = (d.equipped == 1),
        db = db ~= nil,
    }
end

local function sync(p)
    if isElement(p) and Data[p] and Tokens[p] then
        triggerClientEvent(p, "bp:sync", p, Tokens[p], payload(p))
    end
end

local function rollMissions(d)
    if d.mission_date == today() and #(d.missions or {}) > 0 then return false end
    d.mission_date = today()
    d.missions = {}
    for _, diff in ipairs({ "easy", "medium", "hard" }) do
        local pool = BP.Pool[diff]
        local pick = pool[math.random(#pool)]
        d.missions[#d.missions + 1] = {
            type = pick.type, diff = diff, need = pick.need,
            prog = 0, xp = BP.DiffXP[diff], text = pick.text,
        }
    end
    return true
end

local function loadPlayer(p)
    if not isElement(p) then return end
    if Data[p] then save(p) end
    local account = getPlayerAccount(p)
    local key
    if account and not isGuestAccount(account) then
        key = getAccountName(account)
    else
        key = "serial:" .. (getPlayerSerial(p) or "unknown")
    end

    local d
    if db then
        local rows, err = dbCall(db, "SELECT * FROM bp_players WHERE account=? LIMIT 1", key)
        if rows and rows[1] then
            local row = rows[1]
            d = {
                account = key,
                xp = math.max(0, asInt(row.xp)),
                claimed = math.max(0, math.min(BP.Days, asInt(row.claimed))),
                last_claim = asStr(row.last_claim),
                mission_date = asStr(row.mission_date),
                missions = decodeMissions(row.missions),
                coins = math.max(0, asInt(row.coins)),
                emeralds = math.max(0, asInt(row.emeralds)),
                rp = math.max(0, asInt(row.rp)),
                skin_owned = asInt(row.skin_owned) == 1 and 1 or 0,
                equipped = asInt(row.equipped) == 1 and 1 or 0,
            }
            if d.skin_owned ~= 1 then d.equipped = 0 end
            if d.claimed >= BP.Days then d.skin_owned = 1 end
        elseif rows then
            d = fresh(key)
            if not dbCall(db, "INSERT INTO bp_players (account, name) VALUES (?,?)", key, cleanName(p)) then
                outputDebugString("[BattlePass] insert failed for " .. key, 1)
            end
        else
            outputDebugString("[BattlePass] load failed for " .. key .. ": " .. tostring(err), 1)
            d = fresh(key)
        end
    else
        d = fresh(key)
    end

    Data[p] = d
    Tokens[p] = md5(("%s|%s|%s"):format(getTickCount(), math.random(1, 2147483647), key))
    if rollMissions(d) then save(p) end
    return d
end

-- ---------------------------------------------------------------- economy
-- Replace the coins / emerald / rp branches if the server has its own economy.
local function giveCurrency(p, d, kind, amount)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 then return end
    if kind == "money" then
        givePlayerMoney(p, amount)
    elseif kind == "coins" then
        d.coins = d.coins + amount
    elseif kind == "emerald" then
        d.emeralds = d.emeralds + amount
    elseif kind == "rp" then
        d.rp = d.rp + amount
    end
end

-- ---------------------------------------------------------------- missions
local function addProgress(p, mtype, amt)
    local d = Data[p]
    if not d or d.claimed >= BP.Days then return end
    if d.last_claim == today() then return end
    if not d.missions or #d.missions == 0 then return end
    local changed = false
    for _, mission in ipairs(d.missions) do
        if mission.type == mtype and mission.prog < mission.need then
            mission.prog = math.min(mission.need, mission.prog + amt)
            changed = true
            if mission.prog >= mission.need then
                d.xp = d.xp + mission.xp
                notify(p, "Mission complete: " .. mission.text .. "  +" .. mission.xp .. " XP", "ok")
            end
        end
    end
    if changed then save(p); sync(p) end
end

function addMissionProgress(player, mtype, amount)
    if sourceResource == getThisResource() then return false end
    if not isElement(player) or getElementType(player) ~= "player" then return false end
    if not ALLOWED[mtype] then return false end
    amount = tonumber(amount) or 1
    if amount < 1 or amount > 10 then return false end
    if not Data[player] then return false end
    addProgress(player, mtype, math.floor(amount))
    return true
end

addEventHandler("onPlayerWasted", root, function(_, killer, _, bodypart)
    if isElement(killer) and killer ~= source and getElementType(killer) == "player" and Data[killer] then
        addProgress(killer, "kills", 1)
        if bodypart == 9 then addProgress(killer, "headshots", 1) end
    end
end)

addEventHandler("onPlayerVehicleEnter", root, function()
    local now = getTickCount()
    if Data[source] and (not LastVeh[source] or now - LastVeh[source] > 15000) then
        LastVeh[source] = now
        addProgress(source, "vehicle", 1)
    end
end)

setTimer(function()
    local day = today()
    for _, p in ipairs(getElementsByType("player")) do
        local d = Data[p]
        if d then
            if d.mission_date ~= day then
                if rollMissions(d) then
                    save(p); sync(p)
                    notify(p, "New daily missions are ready.", "info")
                end
            end
            if getElementHealth(p) > 0 then addProgress(p, "playtime", 1) end
        end
    end
end, 60000, 0)

-- ---------------------------------------------------------------- actions
local function doClaim(p)
    local d = Data[p]
    if d.claimed >= BP.Days then return notify(p, "You completed the whole pass.", "warn") end
    if d.last_claim == today() then return notify(p, "You already claimed today's reward.", "warn") end
    if not d.missions or #d.missions == 0 then return notify(p, "Missions are still loading.", "warn") end
    for _, mission in ipairs(d.missions) do
        if mission.prog < mission.need then return notify(p, "Finish all daily missions first.", "warn") end
    end
    local day = d.claimed + 1
    local reward = BP.Rewards[day]
    if not reward then return notify(p, "Reward data is missing for this day.", "warn") end
    d.claimed = day
    d.last_claim = today()
    d.xp = d.xp + BP.DayBonusXP
    if reward.t == "skin" then
        d.skin_owned = 1
    else
        giveCurrency(p, d, reward.t, reward.a)
    end
    if not save(p) then
        notify(p, "Reward granted, but the database did not save. Tell an admin.", "warn")
    end
    sync(p)
    notify(p, "Day " .. day .. " reward claimed.", "ok")
end

local function doUse(p)
    local d = Data[p]
    if d.skin_owned ~= 1 then return strike(p, "use skin not owned") end
    if d.equipped == 1 then
        d.equipped = 0
        if isElement(p) then setElementModel(p, PrevSkin[p] or 0) end
        notify(p, "Santa skin removed.", "info")
    else
        PrevSkin[p] = getElementModel(p)
        d.equipped = 1
        setElementModel(p, BP.SantaSkin)
        notify(p, "Santa skin equipped.", "ok")
    end
    save(p); sync(p)
end

local function doTop(p)
    local out = {}
    if db then
        local rows = dbCall(db, "SELECT name, xp, claimed FROM bp_players ORDER BY xp DESC LIMIT 5")
        if rows then
            for i, row in ipairs(rows) do
                local xp = math.max(0, asInt(row.xp))
                local name = asStr(row.name)
                out[i] = {
                    name = name ~= "" and name or "player",
                    level = math.floor(xp / BP.XPPerLevel) + 1,
                    days = math.max(0, asInt(row.claimed)),
                }
            end
        end
    end
    triggerClientEvent(p, "bp:top", p, out)
end

local COOLDOWN = { claim = 1500, use = 1500, sync = 800, top = 3000 }
local ACTIONS = { claim = doClaim, use = doUse, sync = function(p) sync(p) end, top = doTop }

-- ---------------------------------------------------------------- events
addEvent("bp:init", true)
addEvent("bp:req", true)
addEvent("bp:sync", true)
addEvent("bp:notify", true)
addEvent("bp:top", true)

addEventHandler("bp:init", root, function()
    local p = client
    if not p or source ~= p then return end
    local now = getTickCount()
    LastReq[p] = LastReq[p] or {}
    if now - (LastReq[p].init or 0) < 2000 then return end
    LastReq[p].init = now
    if not Data[p] then loadPlayer(p) end
    if Data[p] then
        sync(p)
        if not db then notify(p, "Database is offline. Progress will not be saved.", "warn") end
    end
end)

addEventHandler("bp:req", root, function(token, action)
    local p = client
    if not p or source ~= p then return end
    if type(token) ~= "string" or type(action) ~= "string" then return strike(p, "bad types") end
    if not Data[p] then return notify(p, "Open the battle pass again.", "warn") end
    if token ~= Tokens[p] then return strike(p, "invalid token") end
    local fn = ACTIONS[action]
    if not fn then return strike(p, "unknown action: " .. action:sub(1, 20)) end
    local now = getTickCount()
    LastReq[p] = LastReq[p] or {}
    if now - (LastReq[p][action] or 0) < (COOLDOWN[action] or 800) then return end
    LastReq[p][action] = now
    fn(p)
end)

addEventHandler("onPlayerLogin", root, function()
    loadPlayer(source)
    if Data[source] then sync(source) end
end)

addEventHandler("onPlayerLogout", root, function()
    save(source)
    Data[source], Tokens[source] = nil, nil
end)

addEventHandler("onPlayerQuit", root, function()
    save(source)
    Data[source], Tokens[source], Strikes[source], LastReq[source], PrevSkin[source], LastVeh[source] = nil, nil, nil, nil, nil, nil
end)

addEventHandler("onPlayerSpawn", root, function()
    local p = source
    if Data[p] and Data[p].equipped == 1 then
        setTimer(function()
            if isElement(p) and Data[p] and Data[p].equipped == 1 then
                setElementModel(p, BP.SantaSkin)
            end
        end, 400, 1)
    end
end)

addEventHandler("onResourceStart", resourceRoot, function()
    openDB()
    for _, p in ipairs(getElementsByType("player")) do
        loadPlayer(p)
        if Data[p] and Data[p].equipped == 1 then
            setElementModel(p, BP.SantaSkin)
        end
    end
end)

addEventHandler("onResourceStop", resourceRoot, function()
    for p in pairs(Data) do
        if isElement(p) then save(p) end
    end
    if db then
        destroyElement(db)
        db = nil
    end
end)
