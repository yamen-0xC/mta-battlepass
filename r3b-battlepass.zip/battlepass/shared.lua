-- R3B Tactics | Battle Pass shared config
-- Loaded by meta.xml as a shared script (server + client).

BP = {}
BP.Days        = 30
BP.SantaSkin   = 67
BP.XPPerLevel  = 1000
BP.DayBonusXP  = 150
BP.MaxStrikes  = 5

-- t: coins | money | rp | emerald | skin
-- Day 30 is always the Santa skin (drawn from santa_skin.png).
BP.Rewards = {
    {t="coins",a=50},      {t="money",a=25000},  {t="rp",a=50},       {t="emerald",a=2},    {t="coins",a=150},
    {t="money",a=40000},   {t="rp",a=100},       {t="emerald",a=3},   {t="coins",a=250},    {t="money",a=60000},
    {t="rp",a=150},        {t="emerald",a=5},    {t="coins",a=350},   {t="money",a=80000},  {t="rp",a=200},
    {t="emerald",a=6},     {t="coins",a=450},    {t="money",a=100000},{t="rp",a=250},       {t="emerald",a=8},
    {t="coins",a=500},     {t="money",a=125000}, {t="rp",a=300},      {t="emerald",a=10},   {t="coins",a=600},
    {t="money",a=150000},  {t="rp",a=400},       {t="emerald",a=15},  {t="coins",a=1000},   {t="skin",skin=67},
}

BP.DiffXP = { easy = 100, medium = 250, hard = 500 }
BP.Pool = {
    easy = {
        {type="kills",    need=3,  text="Eliminate 3 players"},
        {type="playtime", need=10, text="Play for 10 minutes"},
        {type="vehicle",  need=3,  text="Enter 3 vehicles"},
    },
    medium = {
        {type="kills",    need=10, text="Eliminate 10 players"},
        {type="headshots",need=3,  text="Get 3 headshots"},
        {type="playtime", need=30, text="Play for 30 minutes"},
        {type="roundwin", need=1,  text="Win 1 round"},
    },
    hard = {
        {type="kills",    need=25, text="Eliminate 25 players"},
        {type="headshots",need=10, text="Get 10 headshots"},
        {type="roundwin", need=3,  text="Win 3 rounds"},
        {type="playtime", need=60, text="Play for 60 minutes"},
    },
}
