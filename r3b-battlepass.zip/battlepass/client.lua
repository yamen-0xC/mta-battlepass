-- ============================================================
--  R3B TACTICS | Battle Pass (CLIENT)
--  Designed on a 1672x941 canvas and scaled to the screen.
--  Open with F10 or /battlepass.
--  Fonts are real TTF files (cleartype), not scaled bankgothic,
--  so labels stay sharp and never collide.
-- ============================================================

if type(BP) ~= "table" or not BP.Rewards or not BP.Days then
    outputDebugString("[BattlePass] shared.lua did not load. Check meta.xml script order.", 1)
    return
end

addEvent("bp:sync", true)
addEvent("bp:notify", true)
addEvent("bp:top", true)

local sw, sh = guiGetScreenSize()
local W, H = 1672, 941
local PANEL = 0.9
local sc, ox, oy = 1, 0, 0

local function layout()
    sw, sh = guiGetScreenSize()
    sc = math.min(sw * PANEL / W, sh * PANEL / H)
    if sc < 0.01 then sc = 0.01 end
    ox = (sw - W * sc) / 2
    oy = (sh - H * sc) / 2
end

local function X(v) return ox + v * sc end
local function Y(v) return oy + v * sc end
local function Z(v) return v * sc end
local function PX(v) return math.max(1, math.floor(v * sc + 0.5)) end
local function col(r, g, b, a) return tocolor(r, g, b, a or 255) end

local C = {
    white = col(244, 241, 255),
    dim = col(176, 184, 214),
    purple = col(196, 181, 253),
    green = col(74, 222, 128),
    teal = col(52, 211, 153),
    amber = col(251, 191, 36),
    gold = col(255, 208, 92),
}

local UI = {
    open = false, tab = "pass", inv = false, scroll = 0, invRow = 0,
    data = nil, token = nil, toasts = {}, top = {}, init = false, fails = 0,
}
local VIS = 9
local MAXS = BP.Days - 1 - VIS
local mx, my = -1, -1
local btns = {}
local lastInit = 0
local EMPTY = {
    xp = 0, claimed = 0, claimedToday = false, allDone = false,
    missions = {}, coins = 0, emeralds = 0, rp = 0, skin = false, equipped = false, db = true,
}

-- ------------------------------------------------------------------ fonts
local FONT = {}
local function destroyFonts()
    for _, f in pairs(FONT) do
        if isElement(f) then destroyElement(f) end
    end
    FONT = {}
end

local function buildFonts()
    destroyFonts()
    local function make(file, px)
        local size = math.max(11, math.floor(px * sc + 0.5))
        return dxCreateFont(file, size, false, "cleartype") or "default-bold"
    end
    FONT.logo = make("fonts/LiberationSans-Bold.ttf", 26)
    FONT.title = make("fonts/LiberationSans-Bold.ttf", 34)
    FONT.head = make("fonts/LiberationSans-Bold.ttf", 18)
    FONT.ui = make("fonts/LiberationSans-Bold.ttf", 15)
    FONT.small = make("fonts/LiberationSans-Bold.ttf", 12)
    FONT.body = make("fonts/LiberationSans-Regular.ttf", 14)
end

local function textScale(font)
    if type(font) == "string" then return math.max(0.85, sc) end
    return 1
end

-- ------------------------------------------------------------------ svg / images
local cache = {}
local function svgGet(key, pw, ph, vw, vh, body)
    local k = key .. "|" .. pw .. "x" .. ph
    local s = cache[k]
    if s == nil then
        s = svgCreate(pw, ph, '<svg xmlns="http://www.w3.org/2000/svg" width="' .. pw .. '" height="' .. ph .. '" viewBox="0 0 ' .. vw .. ' ' .. vh .. '">' .. body .. '</svg>') or false
        cache[k] = s
    end
    return s
end

local function img(s, x, y, w, h, a)
    if s then dxDrawImage(X(x), Y(y), Z(w), Z(h), s, 0, 0, 0, tocolor(255, 255, 255, a or 255)) end
end

local TEX = { banner = false, skin = false }
local function loadTextures()
    if isElement(TEX.banner) then destroyElement(TEX.banner) end
    if isElement(TEX.skin) then destroyElement(TEX.skin) end
    TEX.banner = dxCreateTexture("santa_banner.png", "argb", false, "clamp")
    TEX.skin = dxCreateTexture("santa_skin.png", "argb", false, "clamp")
    if not TEX.banner or not TEX.skin then
        outputDebugString("[BattlePass] santa_banner.png / santa_skin.png failed to load. Check meta.xml <file> entries.", 1)
    end
end

local function texCover(tex, tw, th, x, y, w, h, ax, ay, a)
    if not isElement(tex) then return end
    local s = math.max(w / tw, h / th)
    local cw, ch = w / s, h / s
    local u = math.max(0, (tw - cw) * (ax or 0.5))
    local v = math.max(0, (th - ch) * (ay or 0.4))
    if u + cw > tw then u = tw - cw end
    if v + ch > th then v = th - ch end
    dxDrawImageSection(X(x), Y(y), Z(w), Z(h), u, v, cw, ch, tex, 0, 0, 0, tocolor(255, 255, 255, a or 255))
end

local function texContain(tex, tw, th, x, y, w, h, a)
    if not isElement(tex) then return end
    local s = math.min(w / tw, h / th)
    local dw, dh = tw * s, th * s
    dxDrawImage(X(x + (w - dw) / 2), Y(y + (h - dh) / 2), Z(dw), Z(dh), tex, 0, 0, 0, tocolor(255, 255, 255, a or 255))
end

local function fadeRight(x, y, w, h, fw)
    fw = fw or 56
    local steps = 12
    for i = 0, steps - 1 do
        local a = math.floor(255 * (i / (steps - 1)))
        dxDrawRectangle(X(x + w - fw + (i * fw / steps)), Y(y), Z(fw / steps + 0.8), Z(h), col(12, 16, 40, a))
    end
end

local function rr(x, y, w, h, r, fill, fo, stroke, so, a)
    local pw, ph = math.max(2, PX(w)), math.max(2, PX(h))
    local rx = math.min((r or 0) * sc, (ph - 2) / 2, (pw - 2) / 2)
    if rx < 0 then rx = 0 end
    local body = ('<rect x="1" y="1" width="%d" height="%d" rx="%.1f" fill="%s" fill-opacity="%.2f" stroke="%s" stroke-opacity="%.2f" stroke-width="2"/>')
        :format(math.max(1, pw - 2), math.max(1, ph - 2), rx, fill or "#000", fill and (fo or 1) or 0, stroke or "#000", stroke and (so or 1) or 0)
    img(svgGet("rr" .. (fill or "n") .. (fo or 1) .. (stroke or "n") .. (so or 1) .. tostring(r), pw, ph, pw, ph, body), x, y, w, h, a)
end

local ICON = {
    hex = function(c) return '<polygon points="50,4 92,27 92,73 50,96 8,73 8,27" fill="#1a1140" stroke="' .. c .. '" stroke-width="6" stroke-linejoin="round"/>' end,
    cash = function() return '<rect x="8" y="30" width="84" height="44" rx="4" fill="#1b6e34" transform="rotate(-8 50 52)"/><rect x="8" y="38" width="84" height="44" rx="4" fill="#2f9e4f" transform="rotate(4 50 60)"/><rect x="16" y="44" width="68" height="32" rx="3" fill="#7ad894"/><circle cx="50" cy="60" r="10" fill="#2f9e4f"/>' end,
    coin = function() return '<defs><radialGradient id="g" cx="0.35" cy="0.3" r="0.75"><stop offset="0" stop-color="#ffe7a3"/><stop offset="1" stop-color="#e08a1e"/></radialGradient></defs><circle cx="50" cy="50" r="44" fill="url(#g)" stroke="#a96a12" stroke-width="5"/><circle cx="50" cy="50" r="32" fill="none" stroke="#fff1c9" stroke-width="3"/>' end,
    gem = function() return '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#b8ffe0"/><stop offset="1" stop-color="#0f8a55"/></linearGradient></defs><polygon points="50,6 86,32 74,90 26,90 14,32" fill="url(#g)" stroke="#e7fff4" stroke-width="3" stroke-linejoin="round"/><polyline points="14,32 50,48 86,32" fill="none" stroke="#f3fff9" stroke-width="2.5"/>' end,
    snow = function(c)
        local t = { '<g stroke="' .. c .. '" stroke-width="5" stroke-linecap="round" fill="none">' }
        for a = 0, 150, 60 do
            t[#t + 1] = '<g transform="rotate(' .. a .. ' 50 50)"><line x1="50" y1="8" x2="50" y2="92"/><polyline points="38,20 50,32 62,20"/><polyline points="38,80 50,68 62,80"/></g>'
        end
        t[#t + 1] = '</g>'
        return table.concat(t)
    end,
    crown = function(c) return '<polygon points="8,78 8,30 30,52 50,14 70,52 92,30 92,78" fill="' .. c .. '"/><rect x="8" y="78" width="84" height="12" rx="3" fill="' .. c .. '"/>' end,
    star = function(c) return '<polygon points="50,6 62,38 96,38 68,58 79,92 50,72 21,92 32,58 4,38 38,38" fill="' .. c .. '"/>' end,
    target = function(c) return '<g fill="none" stroke="' .. c .. '" stroke-width="6" stroke-linecap="round"><circle cx="50" cy="50" r="28"/><circle cx="50" cy="50" r="6" fill="' .. c .. '"/><line x1="50" y1="8" x2="50" y2="26"/><line x1="50" y1="74" x2="50" y2="92"/><line x1="8" y1="50" x2="26" y2="50"/><line x1="74" y1="50" x2="92" y2="50"/></g>' end,
    people = function(c) return '<g fill="' .. c .. '"><circle cx="50" cy="34" r="14"/><path d="M24 84 Q24 56 50 56 Q76 56 76 84Z"/><circle cx="20" cy="42" r="9"/><path d="M2 80 Q2 60 20 60 Q28 60 32 64 Q22 70 22 80Z"/><circle cx="80" cy="42" r="9"/><path d="M98 80 Q98 60 80 60 Q72 60 68 64 Q78 70 78 80Z"/></g>' end,
    left = function(c) return '<polyline points="66,14 32,50 66,86" fill="none" stroke="' .. c .. '" stroke-width="10" stroke-linecap="round" stroke-linejoin="round"/>' end,
    right = function(c) return '<polyline points="34,14 68,50 34,86" fill="none" stroke="' .. c .. '" stroke-width="10" stroke-linecap="round" stroke-linejoin="round"/>' end,
    check = function(c) return '<polyline points="18,52 40,74 82,28" fill="none" stroke="' .. c .. '" stroke-width="12" stroke-linecap="round" stroke-linejoin="round"/>' end,
    close = function(c) return '<g stroke="' .. c .. '" stroke-width="10" stroke-linecap="round"><line x1="22" y1="22" x2="78" y2="78"/><line x1="78" y1="22" x2="22" y2="78"/></g>' end,
    lock = function(c) return '<path d="M30 46 V32 a20 20 0 0 1 40 0 V46" fill="none" stroke="' .. c .. '" stroke-width="8"/><rect x="22" y="44" width="56" height="42" rx="8" fill="' .. c .. '"/>' end,
    bag = function(c) return '<path d="M18 36 H82 L90 90 H10Z" fill="' .. c .. '"/><path d="M36 40 V26 a14 14 0 0 1 28 0 V40" fill="none" stroke="' .. c .. '" stroke-width="8"/>' end,
}

local function icon(name, x, y, s, c, a)
    local pw = math.max(8, PX(s))
    img(svgGet("ic" .. name .. (c or ""), pw, pw, 100, 100, ICON[name](c or "#a78bfa")), x, y, s, s, a)
end

local function sceneBody(w, h)
    local t = {
        '<defs><linearGradient id="s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#241a4e"/><stop offset="1" stop-color="#0c1024"/></linearGradient></defs>',
        ('<rect width="%d" height="%d" fill="url(#s)"/>'):format(w, h),
    }
    t[#t + 1] = ('<polygon points="0,%d %d,%d %d,%d %d,%d %d,%d %d,%d %d,%d" fill="#1a2048"/>'):format(
        h, w * .18, h * .55, w * .36, h * .72, w * .55, h * .38, w * .74, h * .66, w, h * .5, w, h)
    t[#t + 1] = ('<polygon points="0,%d %d,%d %d,%d %d,%d %d,%d" fill="#12183a"/>'):format(
        h, w * .22, h * .7, w * .48, h * .84, w * .7, h * .64, w, h)
    for i = 0, 42 do
        local x = i * w / 42
        local th = h * (0.28 + ((i * 37) % 5) * 0.045)
        t[#t + 1] = ('<polygon points="%d,%d %d,%d %d,%d" fill="#090c22"/>'):format(x - w * .012, h, x, h - th, x + w * .012, h)
    end
    for i = 0, 48 do
        t[#t + 1] = ('<circle cx="%d" cy="%d" r="1.4" fill="#ffffff" fill-opacity="0.55"/>'):format((i * 197) % math.max(w, 1), (i * 83) % math.max(math.floor(h * 0.72), 1))
    end
    return table.concat(t)
end

local function scene(x, y, w, h, a)
    local pw, ph = PX(w), PX(h)
    img(svgGet("scene" .. pw .. "x" .. ph, pw, ph, pw, ph, sceneBody(pw, ph)), x, y, w, h, a)
end

-- ------------------------------------------------------------------ text / input
local function txt(text, x, y, w, h, c, font, ax, ay, wrap)
    font = font or FONT.ui
    dxDrawText(tostring(text), X(x), Y(y), X(x + w), Y(y + h), c, textScale(font), font, ax or "left", ay or "center", true, wrap and true or false, false, false, true)
end

local function txtFit(text, x, y, w, h, c, font, ax, ay)
    font = font or FONT.small
    text = tostring(text)
    local scale = textScale(font)
    local tw = dxGetTextWidth(text, scale, font)
    local limit = math.max(4, (w - 4) * sc)
    if tw > limit and tw > 0 then scale = scale * (limit / tw) end
    dxDrawText(text, X(x), Y(y), X(x + w), Y(y + h), c, scale, font, ax or "center", ay or "center", true, false, false, false, true)
end

local function hit(x, y, w, h)
    return mx >= x and mx <= x + w and my >= y and my <= y + h
end

local function button(x, y, w, h, cb)
    btns[#btns + 1] = { x, y, w, h, cb }
    return hit(x, y, w, h)
end

local function req(action)
    if not UI.token then
        triggerServerEvent("bp:init", localPlayer)
        return
    end
    triggerServerEvent("bp:req", localPlayer, UI.token, action)
end

local function commas(n)
    local s = tostring(math.floor(tonumber(n) or 0))
    local out, count = "", 0
    for i = #s, 1, -1 do
        count = count + 1
        out = s:sub(i, i) .. out
        if count == 3 and i > 1 then
            out = "," .. out
            count = 0
        end
    end
    return out
end

local function rinfo(r)
    if not r then return "Reward", C.dim end
    if r.t == "rp" then return r.a .. " RP", C.purple
    elseif r.t == "money" then return commas(r.a) .. " R3BMoney", C.green
    elseif r.t == "coins" then return commas(r.a) .. " Coins", C.amber
    elseif r.t == "emerald" then return r.a .. " Emerald", C.teal
    else return "SANTA SKIN", C.white end
end

local function drawReward(r, cx, cy, s)
    if not r then return end
    local x, y = cx - s / 2, cy - s / 2
    if r.t == "rp" then
        icon("hex", x, y, s, "#7c3aed")
        txt("RP", x, y, s, s, C.purple, FONT.small, "center", "center", false)
    elseif r.t == "money" then
        icon("cash", x, y, s)
    elseif r.t == "coins" then
        icon("coin", x, y, s)
        txt("R", x, y, s, s, col(120, 72, 10), FONT.ui, "center", "center", false)
    elseif r.t == "emerald" then
        icon("gem", x, y, s)
    else
        texContain(TEX.skin, 618, 612, x, y, s, s)
    end
end

local function toast(msg, kind)
    UI.toasts[#UI.toasts + 1] = { msg = msg, kind = kind, t = getTickCount() }
end

-- ------------------------------------------------------------------ blocks
local function drawHeader()
    icon("crown", 40, 36, 30, "#c4b5fd")
    txt("R3B", 78, 28, 120, 34, col(196, 181, 253), FONT.logo, "left", "center", false)
    txt("TACTICS", 78, 58, 140, 20, C.white, FONT.small, "left", "center", false)
    dxDrawRectangle(X(214), Y(38), Z(1), Z(36), col(70, 78, 120))
    txt("SINCE 2023", 230, 38, 150, 36, C.dim, FONT.small, "left", "center", false)

    rr(400, 28, 560, 58, 10, "#10162e", 1, "#2c335f", 1)
    local tabs = {
        { "pass", "BATTLE PASS", "star", 400, 210 },
        { "missions", "MISSIONS", "target", 610, 170 },
        { "battle", "OUR BATTLE", "people", 780, 180 },
    }
    for _, t in ipairs(tabs) do
        local on = UI.tab == t[1]
        if on then
            rr(t[4], 28, t[5], 58, 10, "#2a1b58", 1, "#7c3aed", 0.9)
        end
        icon(t[3], t[4] + 14, 42, 28, on and "#c4b5fd" or "#9aa3c7")
        txt(t[2], t[4] + 48, 28, t[5] - 58, 58, on and C.white or C.dim, FONT.ui, "left", "center", false)
        if not UI.inv then
            button(t[4], 28, t[5], 58, function()
                UI.tab = t[1]
                if t[1] == "battle" then req("top") end
            end)
        end
    end

    local itemsHot = hit(980, 28, 148, 58) and not UI.inv
    rr(980, 28, 148, 58, 10, itemsHot and "#342066" or "#1c1544", 1, "#7c3aed", 0.85)
    icon("bag", 996, 44, 26, "#c4b5fd")
    txt("ITEMS", 1028, 28, 90, 58, C.white, FONT.ui, "left", "center", false)
    if not UI.inv then button(980, 28, 148, 58, function() UI.inv = true UI.invRow = 0 end) end

    rr(1144, 28, 492, 58, 10, "#10162e", 1, "#2c335f", 1)
    icon("hex", 1160, 40, 34, "#7c3aed")
    txt("RP", 1160, 40, 34, 34, C.purple, FONT.small, "center", "center", false)
    txt(tostring(UI.data and UI.data.rp or 0), 1204, 28, 90, 58, C.white, FONT.head, "left", "center", false)
    dxDrawRectangle(X(1304), Y(42), Z(1), Z(30), col(70, 78, 120))
    icon("crown", 1320, 44, 24, "#c4b5fd")
    txt("R3B TACTICS", 1352, 28, 260, 58, C.dim, FONT.small, "left", "center", false)
end

local function drawBanner(d)
    rr(28, 112, 1616, 240, 12, "#0c1024", 1, "#2c335f", 1)
    scene(29, 113, 1614, 238, 255)
    rr(29, 113, 1614, 238, 12, "#070b1c", 0.28)

    local ix, iy, iw, ih = 46, 128, 340, 208
    if isElement(TEX.banner) then
        texCover(TEX.banner, 900, 680, ix, iy, iw, ih, 0.42, 0.38, 255)
        fadeRight(ix, iy, iw, ih, 70)
        rr(ix, iy, iw, ih, 10, nil, nil, "#c4b5fd", 0.45)
    else
        rr(ix, iy, iw, ih, 10, "#1a1440", 1, "#7c3aed", 0.6)
        txt("SANTA BANNER", ix, iy, iw, ih, C.dim, FONT.ui, "center", "center", false)
    end

    txt("BATTLE PASS", 414, 136, 560, 52, C.white, FONT.title, "left", "center", false)
    txt("WINTER SEASON", 416, 192, 420, 28, C.purple, FONT.head, "left", "center", false)
    txt("Complete battles, earn rewards, and level up your battle pass.", 416, 230, 500, 64, C.dim, FONT.body, "left", "top", true)

    local xp = d and tonumber(d.xp) or 0
    local lvl = math.floor(xp / BP.XPPerLevel) + 1
    local cur = xp % BP.XPPerLevel
    icon("hex", 1040, 156, 52, "#7c3aed")
    icon("star", 1054, 170, 24, "#ddd6fe")
    txt("LEVEL " .. lvl, 1104, 150, 250, 32, C.white, FONT.head, "left", "center", false)
    rr(1104, 196, 300, 14, 7, "#2a315c", 1)
    if cur > 0 then
        local fill = math.max(14, 300 * cur / BP.XPPerLevel)
        rr(1104, 196, fill, 14, 7, "#7c3aed", 1)
    end
    txt(cur .. " / " .. BP.XPPerLevel, 1416, 186, 180, 32, C.white, FONT.ui, "left", "center", false)
end

local function claimState(d, fails)
    if not d then
        if fails >= 3 then return "RECONNECTING", false end
        return "LOADING", false
    end
    if d.db == false then return "DATABASE OFFLINE", false end
    if d.claimed >= BP.Days then return "PASS COMPLETED", false end
    if d.claimedToday then return "COME BACK TOMORROW", false end
    if d.allDone then return "CLAIM DAY " .. (d.claimed + 1), true end
    local n = 0
    for _, m in ipairs(d.missions or {}) do
        if m.prog >= m.need then n = n + 1 end
    end
    return "FINISH MISSIONS  " .. n .. "/" .. tostring(#(d.missions or {})), false
end

local function drawStrip(d, pulse)
    rr(28, 776, 1616, 132, 12, "#0c1024", 1, "#2c335f", 1)
    scene(29, 777, 1614, 130, 140)
    icon("crown", 56, 812, 48, "#c4b5fd")
    txt("LEVEL UP", 118, 804, 280, 36, C.purple, FONT.head, "left", "center", false)
    txt("EARN REWARDS", 118, 842, 280, 24, C.dim, FONT.small, "left", "center", false)

    local label, active = claimState(d, UI.fails)
    local hot = hit(460, 812, 520, 58)
    if active then
        rr(452, 804, 536, 74, 14, "#7c3aed", 0.16 + pulse * 0.2)
        rr(460, 812, 520, 58, 10, hot and "#8b5cf6" or "#7c3aed", 1, "#ddd6fe", 0.9)
        button(460, 812, 520, 58, function() req("claim") end)
    else
        rr(460, 812, 520, 58, 10, "#161b3a", 0.95, "#2c335f", 1)
    end
    txtFit(label, 472, 812, 496, 58, active and C.white or C.dim, FONT.ui, "center", "center")

    dxDrawRectangle(X(1048), Y(812), Z(1), Z(58), col(70, 78, 120))
    txt("R3B", 1072, 804, 150, 70, col(196, 181, 253), FONT.logo, "center", "center", false)
    dxDrawRectangle(X(1240), Y(808), Z(1), Z(66), col(70, 78, 120))
    txt("MORE THAN A SERVER", 1264, 816, 280, 24, C.dim, FONT.small, "left", "center", false)
    txt("IT'S A COMMUNITY", 1264, 842, 280, 24, C.white, FONT.small, "left", "center", false)
    icon("crown", 1568, 828, 22, "#c4b5fd")
end

local function drawTrack(d, pulse)
    rr(28, 368, 1616, 392, 12, "#10162e", 1, "#2c335f", 1)

    rr(86, 430, 96, 200, 10, "#182048", 1, "#3a4478", 0.9)
    icon("snow", 102, 468, 64, "#dbe4ff")
    txt("FREE", 86, 548, 96, 26, C.white, FONT.ui, "center", "center", false)
    txt("PASS", 86, 574, 96, 22, C.dim, FONT.small, "center", "center", false)

    local claimed = d and tonumber(d.claimed) or 0
    local cardW, gap = 112, 12
    local startX = 204
    for i = 0, VIS - 1 do
        local day = UI.scroll + 1 + i
        local x, y = startX + i * (cardW + gap), 444
        local done = day <= claimed
        local cur = day == claimed + 1
        local reward = BP.Rewards[day]
        txt(tostring(day), x, y - 26, cardW, 22, cur and C.white or C.dim, FONT.small, "center", "center", false)
        rr(x, y, cardW, 176, 10, cur and "#221a4e" or "#121735", 1, cur and "#7c3aed" or "#2c335f", 1)
        if cur then rr(x - 3, y - 3, cardW + 6, 182, 12, nil, nil, "#c4b5fd", 0.25 + pulse * 0.45) end
        drawReward(reward, x + cardW / 2, y + 62, 58)
        local label, c = rinfo(reward)
        txtFit(label, x + 4, y + 132, cardW - 8, 36, c, FONT.small, "center", "center")
        if done then
            rr(x, y, cardW, 176, 10, "#070b18", 0.45)
            rr(x + cardW - 32, y + 8, 24, 24, 12, "#22c55e", 1)
            icon("check", x + cardW - 28, y + 12, 16, "#ffffff")
        elseif not cur then
            icon("lock", x + cardW - 30, y + 8, 18, "#8b93b8")
        elseif d and d.claimedToday then
            txt("NEXT", x, y + 6, cardW, 18, C.amber, FONT.small, "center", "center", false)
        end
    end

    local fx, fy, fw, fh = 1396, 418, 176, 214
    local own = d and d.skin
    local featuredCur = (claimed + 1) == BP.Days
    rr(fx - 3, fy - 3, fw + 6, fh + 6, 14, nil, nil, "#c4b5fd", 0.35 + (featuredCur and pulse * 0.4 or 0.1))
    rr(fx, fy, fw, fh, 12, "#241a52", 1, "#7c3aed", 1)
    icon("crown", fx + fw / 2 - 14, fy - 16, 28, "#c4b5fd")
    if isElement(TEX.skin) then
        texContain(TEX.skin, 618, 612, fx + 14, fy + 14, fw - 28, 140)
    else
        txt("SANTA", fx, fy + 50, fw, 30, C.dim, FONT.ui, "center", "center", false)
    end
    txt("SANTA SKIN", fx + 8, fy + 162, fw - 16, 28, C.white, FONT.small, "center", "center", false)
    txt("DAY 30", fx + 8, fy + 186, fw - 16, 20, C.purple, FONT.small, "center", "center", false)
    if own then
        rr(fx + fw - 34, fy + 10, 24, 24, 12, "#22c55e", 1)
        icon("check", fx + fw - 30, fy + 14, 16, "#ffffff")
    else
        icon("lock", fx + fw - 32, fy + 10, 18, "#c4b5fd")
    end

    local lineY = 668
    local firstCx = startX + cardW / 2
    local lastCx = startX + (VIS - 1) * (cardW + gap) + cardW / 2
    dxDrawRectangle(X(firstCx), Y(lineY), Z(lastCx - firstCx), Z(4), col(42, 48, 92))
    if claimed > UI.scroll then
        local reached = math.max(0, math.min(VIS - 1, claimed - UI.scroll - 1))
        local to = startX + reached * (cardW + gap) + cardW / 2
        if to > firstCx then
            dxDrawRectangle(X(firstCx), Y(lineY), Z(to - firstCx), Z(4), col(124, 58, 237))
        end
    end
    for i = 0, VIS - 1 do
        local day = UI.scroll + 1 + i
        local cx = startX + i * (cardW + gap) + cardW / 2
        local on = day <= claimed
        rr(cx - 13, lineY - 11, 26, 26, 13, on and "#7c3aed" or "#171c3e", 1, on and "#ddd6fe" or "#3a4478", 1)
        txt(tostring(day), cx - 13, lineY - 11, 26, 26, C.white, FONT.small, "center", "center", false)
    end
    local santaCx = fx + fw / 2
    rr(santaCx - 16, lineY - 13, 32, 32, 16, own and "#7c3aed" or "#2a1b58", 1, "#c4b5fd", 1)
    txt("30", santaCx - 16, lineY - 13, 32, 32, C.white, FONT.small, "center", "center", false)

    local leftHot = hit(36, 500, 40, 48)
    local rightHot = hit(1596, 500, 40, 48)
    icon("left", 40, 508, 30, leftHot and "#ffffff" or "#c4b5fd")
    icon("right", 1600, 508, 30, rightHot and "#ffffff" or "#c4b5fd")
    button(36, 500, 40, 48, function() UI.scroll = math.max(0, UI.scroll - 1) end)
    button(1596, 500, 40, 48, function() UI.scroll = math.min(MAXS, UI.scroll + 1) end)
end

local DIFFC = {
    easy = { "#16a34a", "EASY" },
    medium = { "#d97706", "MEDIUM" },
    hard = { "#dc2626", "HARD" },
}

local function drawMissions(d)
    rr(28, 368, 1616, 392, 12, "#10162e", 1, "#2c335f", 1)
    txt("DAILY MISSIONS", 56, 386, 520, 32, C.white, FONT.head, "left", "center", false)
    txt("Finish all three to unlock today's reward. They reset every day.", 56, 420, 900, 24, C.dim, FONT.body, "left", "center", false)
    local missions = d and d.missions or {}
    if #missions == 0 then
        txt("Missions will appear as soon as the server replies.", 56, 480, 800, 30, C.dim, FONT.ui, "left", "center", false)
        return
    end
    for i, m in ipairs(missions) do
        local x, y, w = 56 + (i - 1) * 520, 462, 496
        local done = m.prog >= m.need
        local dc = DIFFC[m.diff] or DIFFC.easy
        rr(x, y, w, 250, 12, "#121735", 1, done and "#22c55e" or "#2c335f", 1)
        rr(x + 20, y + 20, 108, 30, 8, dc[1], 0.22, dc[1], 0.95)
        txt(dc[2], x + 20, y + 20, 108, 30, C.white, FONT.small, "center", "center", false)
        txt("+" .. tostring(m.xp) .. " XP", x + w - 150, y + 20, 126, 30, C.purple, FONT.ui, "right", "center", false)
        txt(m.text or "", x + 20, y + 70, w - 40, 64, C.white, FONT.head, "left", "top", true)
        local frac = 0
        if m.need > 0 then frac = math.min(1, (tonumber(m.prog) or 0) / m.need) end
        rr(x + 20, y + 160, w - 40, 14, 7, "#2a315c", 1)
        if frac > 0 then
            rr(x + 20, y + 160, math.max(14, (w - 40) * frac), 14, 7, done and "#22c55e" or "#7c3aed", 1)
        end
        txt(math.min(m.prog or 0, m.need or 0) .. " / " .. tostring(m.need), x + 20, y + 186, 220, 30, C.dim, FONT.ui, "left", "center", false)
        if done then icon("check", x + w - 52, y + 182, 28, "#22c55e") end
    end
end

local function drawBattle()
    rr(28, 368, 1616, 392, 12, "#10162e", 1, "#2c335f", 1)
    txt("TOP PLAYERS", 56, 386, 400, 32, C.white, FONT.head, "left", "center", false)
    if #UI.top == 0 then
        txt("No ranked players yet.", 56, 440, 500, 28, C.dim, FONT.ui, "left", "center", false)
        return
    end
    for i, p in ipairs(UI.top) do
        if i > 5 then break end
        local y = 436 + (i - 1) * 58
        rr(56, y, 1560, 50, 10, i == 1 and "#2a1b58" or "#121735", 1, "#2c335f", 1)
        txt("#" .. i, 76, y, 50, 50, i == 1 and C.gold or C.dim, FONT.ui, "left", "center", false)
        txt(p.name or "player", 140, y, 700, 50, C.white, FONT.ui, "left", "center", false)
        txt("LEVEL " .. tostring(p.level or 1), 980, y, 220, 50, C.purple, FONT.ui, "left", "center", false)
        txt("DAY " .. tostring(p.days or 0) .. " / " .. BP.Days, 1240, y, 340, 50, C.dim, FONT.ui, "right", "center", false)
    end
end

local function drawInventory(d)
    dxDrawRectangle(X(0), Y(0), Z(W), Z(H), col(4, 6, 16, 210))
    local px, py, pw, ph = 336, 150, 1000, 660
    rr(px, py, pw, ph, 14, "#0e1330", 1, "#7c3aed", 0.9)
    txt("MY ITEMS", px + 32, py + 18, 360, 40, C.white, FONT.head, "left", "center", false)
    local hc = hit(px + pw - 64, py + 18, 40, 40)
    rr(px + pw - 64, py + 18, 40, 40, 10, hc and "#3b2a80" or "#1d1646", 1, "#7c3aed", 1)
    icon("close", px + pw - 54, py + 28, 20, "#ffffff")
    button(px + pw - 64, py + 18, 40, 40, function() UI.inv = false end)

    icon("coin", px + 32, py + 74, 32)
    txt(commas(d and d.coins or 0), px + 72, py + 74, 150, 32, C.gold, FONT.ui, "left", "center", false)
    icon("gem", px + 250, py + 74, 32)
    txt(tostring(d and d.emeralds or 0), px + 290, py + 74, 120, 32, C.teal, FONT.ui, "left", "center", false)
    icon("hex", px + 440, py + 74, 32, "#7c3aed")
    txt(tostring(d and d.rp or 0) .. " RP", px + 480, py + 74, 160, 32, C.purple, FONT.ui, "left", "center", false)

    local items = {}
    if d then
        for day = 1, math.min(d.claimed or 0, BP.Days - 1) do
            items[#items + 1] = { day = day, r = BP.Rewards[day] }
        end
        items[#items + 1] = { day = BP.Days, r = BP.Rewards[BP.Days], skin = true, owned = d.skin }
    end
    if #items == 0 then
        txt("Claim a day to fill this locker.", px, py + 280, pw, 30, C.dim, FONT.ui, "center", "center", false)
    end
    local cols, cw, ch, gap = 5, 176, 150, 14
    local rows = math.ceil(#items / cols)
    local maxRow = math.max(0, rows - 3)
    UI.invRow = math.max(0, math.min(maxRow, UI.invRow))
    for idx = 1, #items do
        local rw = math.floor((idx - 1) / cols) - UI.invRow
        local cl = (idx - 1) % cols
        if rw >= 0 and rw < 3 then
            local it = items[idx]
            local x = px + 28 + cl * (cw + gap)
            local y = py + 130 + rw * (ch + gap)
            local locked = it.skin and not it.owned
            rr(x, y, cw, ch, 10, it.skin and "#241a52" or "#121735", 1, it.skin and "#7c3aed" or "#2c335f", 1)
            drawReward(it.r, x + cw / 2, y + 48, 52)
            local label, c = rinfo(it.r)
            txtFit(label, x + 6, y + 86, cw - 12, 22, c, FONT.small, "center", "center")
            if it.skin then
                if locked then
                    icon("lock", x + cw - 30, y + 8, 18, "#c4b5fd")
                    txt("DAY 30", x, y + 114, cw, 24, C.dim, FONT.small, "center", "center", false)
                else
                    local eq = d.equipped
                    local hv = hit(x + 16, y + 114, cw - 32, 28)
                    rr(x + 16, y + 114, cw - 32, 28, 8, eq and (hv and "#dc2626" or "#b91c1c") or (hv and "#8b5cf6" or "#7c3aed"), 1)
                    txt(eq and "UNEQUIP" or "USE", x + 16, y + 114, cw - 32, 28, C.white, FONT.small, "center", "center", false)
                    button(x + 16, y + 114, cw - 32, 28, function() req("use") end)
                end
            else
                txt("DAY " .. it.day, x, y + 114, cw, 24, C.dim, FONT.small, "center", "center", false)
            end
        end
    end
end

local function drawToasts()
    local now = getTickCount()
    for i = #UI.toasts, 1, -1 do
        if now - UI.toasts[i].t > 4200 then table.remove(UI.toasts, i) end
    end
    local tw, th = 520, 40
    local above = oy > 58
    for i, t in ipairs(UI.toasts) do
        if i > 3 then break end
        local x = (sw - tw) / 2
        local y = (above and math.max(8, oy - 50) or (oy + Z(H) + 8)) + (i - 1) * 46
        local stripe = t.kind == "ok" and col(34, 197, 94) or (t.kind == "warn" and col(245, 158, 11) or col(124, 58, 237))
        dxDrawRectangle(x, y, tw, th, col(12, 16, 40, 235))
        dxDrawRectangle(x, y, 4, th, stripe)
        dxDrawText(tostring(t.msg), x + 16, y, x + tw - 12, y + th, C.white, textScale(FONT.ui), FONT.ui or "default-bold", "center", "center", true, false, true, false, true)
    end
end

-- ------------------------------------------------------------------ render
local function render()
    local nsw, nsh = guiGetScreenSize()
    if nsw ~= sw or nsh ~= sh then
        layout()
        buildFonts()
        cache = {}
    end
    local cx, cy = getCursorPosition()
    if cx then
        mx, my = (cx * sw - ox) / sc, (cy * sh - oy) / sc
    else
        mx, my = -1, -1
    end
    btns = {}
    local real = UI.data
    local d = real or EMPTY
    local pulse = (math.sin(getTickCount() / 280) + 1) / 2

    if not real and getTickCount() - lastInit > 3000 then
        lastInit = getTickCount()
        UI.fails = UI.fails + 1
        triggerServerEvent("bp:init", localPlayer)
    end

    dxDrawRectangle(0, 0, sw, sh, col(0, 0, 0, 120))
    dxDrawRectangle(X(0), Y(0), Z(W), Z(H), col(8, 10, 24, 255))
    rr(0, 0, W, H, 14, nil, nil, "#2c335f", 1)
    drawHeader()
    drawBanner(real or d)
    if UI.tab == "pass" then drawTrack(d, pulse)
    elseif UI.tab == "missions" then drawMissions(d)
    else drawBattle() end
    drawStrip(real, pulse)
    if UI.inv then drawInventory(d) end
    drawToasts()
end

addEventHandler("onClientClick", root, function(button, state)
    if not UI.open or button ~= "left" or state ~= "down" then return end
    for i = #btns, 1, -1 do
        local v = btns[i]
        if hit(v[1], v[2], v[3], v[4]) then
            v[5]()
            return
        end
    end
end)

local function wheel(dir)
    if not UI.open then return end
    if UI.inv then
        UI.invRow = UI.invRow + dir
    elseif UI.tab == "pass" then
        UI.scroll = math.max(0, math.min(MAXS, UI.scroll + dir))
    end
end
bindKey("mouse_wheel_up", "down", function() wheel(-1) end)
bindKey("mouse_wheel_down", "down", function() wheel(1) end)

local function toggle()
    if UI.open then
        UI.open = false
        removeEventHandler("onClientRender", root, render)
        showCursor(false)
    else
        UI.open, UI.inv = true, false
        addEventHandler("onClientRender", root, render)
        showCursor(true)
        req("sync")
    end
end
bindKey("F10", "down", toggle)
addCommandHandler("battlepass", toggle)

addEventHandler("bp:sync", root, function(token, data)
    if source ~= localPlayer or type(token) ~= "string" or type(data) ~= "table" then return end
    UI.token, UI.data, UI.fails = token, data, 0
    if type(data.missions) ~= "table" then data.missions = {} end
    if not UI.init then
        UI.init = true
        UI.scroll = math.max(0, math.min(MAXS, (tonumber(data.claimed) or 0) - 2))
    end
end)

addEventHandler("bp:notify", root, function(msg, kind)
    if source == localPlayer then toast(msg, kind) end
end)

addEventHandler("bp:top", root, function(list)
    if source == localPlayer then UI.top = type(list) == "table" and list or {} end
end)

local function restore()
    layout()
    buildFonts()
    loadTextures()
    cache = {}
end

addEventHandler("onClientRestore", root, restore)

addEventHandler("onClientResourceStart", resourceRoot, function()
    layout()
    buildFonts()
    loadTextures()
    outputDebugString("[BattlePass] ready. Press F10 or type /battlepass")
    triggerServerEvent("bp:init", localPlayer)
end)

addEventHandler("onClientResourceStop", resourceRoot, function()
    if UI.open then showCursor(false) end
    destroyFonts()
    if isElement(TEX.banner) then destroyElement(TEX.banner) end
    if isElement(TEX.skin) then destroyElement(TEX.skin) end
    for _, s in pairs(cache) do
        if isElement(s) then destroyElement(s) end
    end
end)
